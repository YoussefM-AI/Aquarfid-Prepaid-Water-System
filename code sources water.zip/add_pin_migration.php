<?php
/**
 * Script d'initialisation des PINs de démonstration.
 * La colonne code_pin est maintenant créée AUTOMATIQUEMENT par Database.php
 * Ce script sert uniquement à définir les PINs de test pour les cartes de démo.
 *
 * Ouvrir une seule fois : http://localhost/water/add_pin_migration.php
 * Supprimer ce fichier après utilisation.
 */

// Autoloader minimal
spl_autoload_register(function ($class) {
    $prefix   = 'App\\';
    $base_dir = __DIR__ . '/app/';
    $len      = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;
    $file = $base_dir . str_replace('\\', '/', substr($class, $len)) . '.php';
    if (file_exists($file)) require $file;
});

use App\Core\Session;
Session::start();

echo '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<title>Migration PIN</title>
<style>
  body { font-family: monospace; background:#0f172a; color:#e2e8f0; padding:40px; }
  .ok  { color:#10B981; } .err { color:#EF4444; } .warn { color:#F59E0B; }
  pre  { background:#1e293b; padding:16px; border-radius:8px; }
  h2   { color:#38BDF8; }
  .box { background:#1e293b; border:1px solid #334155; border-radius:12px; padding:24px; max-width:600px; }
</style></head><body><div class="box">';

echo '<h2>🔑 Initialisation des PINs de démonstration</h2>';

try {
    $db = \App\Core\Database::getInstance()->getConnection();

    // Vérifier si la colonne existe (créée auto par Database.php)
    $stmt = $db->query("SHOW COLUMNS FROM `cartes_rfid` LIKE 'code_pin'");
    if ($stmt->rowCount() === 0) {
        echo '<p class="err">❌ La colonne code_pin n\'existe pas encore.<br>
              Rechargez la page — Database.php la crée automatiquement.</p>';
        exit;
    }
    echo '<p class="ok">✅ Colonne <code>code_pin</code> présente.</p>';

    // PINs de démo
    $demoPins = [
        '04A32B125C6D80' => '1234',  // Mohamed Ben Ali
        '04B76C982A1E40' => '5678',  // Amira Trabelsi
    ];

    $stmtUpd = $db->prepare("UPDATE `cartes_rfid` SET `code_pin` = :hash WHERE `uid` = :uid");

    foreach ($demoPins as $uid => $pin) {
        $hash = password_hash($pin, PASSWORD_BCRYPT);
        $ok   = $stmtUpd->execute(['hash' => $hash, 'uid' => $uid]);
        if ($ok && $stmtUpd->rowCount() > 0) {
            echo "<p class='ok'>✅ PIN <strong>{$pin}</strong> → carte <code>{$uid}</code></p>";
        } else {
            echo "<p class='warn'>⚠️ Carte <code>{$uid}</code> introuvable en base.</p>";
        }
    }

    echo '<hr style="border-color:#334155;margin:20px 0;">';
    echo '<h2>📋 PINs de test disponibles</h2>';
    echo '<pre>';
    echo "Mohamed Ben Ali  (04A32B125C6D80) → PIN : 1234\n";
    echo "Amira Trabelsi   (04B76C982A1E40) → PIN : 5678\n";
    echo '</pre>';

    echo '<p class="ok" style="font-weight:bold;">✅ Migration terminée !</p>';
    echo '<p>→ Allez sur <a href="http://localhost/water/public/kiosk.html" style="color:#38BDF8;">le kiosk</a> et testez le mode PIN.</p>';
    echo '<p class="err">⚠️ Supprimez ce fichier après utilisation !</p>';

} catch (Exception $e) {
    echo '<p class="err">❌ Erreur : ' . htmlspecialchars($e->getMessage()) . '</p>';
}

echo '</div></body></html>';
