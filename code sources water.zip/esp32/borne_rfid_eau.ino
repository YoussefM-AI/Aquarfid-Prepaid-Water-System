/**
 * ============================================================
 * BORNE RFID EAU AGRICOLE — ESP32
 * ============================================================
 * Auteur  : H2O RFID System
 * Version : 2.0.0
 * Date    : 2026
 *
 * MATÉRIEL REQUIS :
 *  - ESP32 (DevKit v1 ou équivalent)
 *  - Lecteur RFID MFRC522 (SPI)
 *  - Débitmètre à impulsions DN100 (ex: YF-DN100, 1 imp/0.1L)
 *  - Électrovanne DN100 (commandée via relais 5V)
 *  - Capteur de trop-plein (flotteur NO/NF)
 *  - Capteur de fuite (sonde ou comparaison débit)
 *  - Relais 5V (canal unique ou module 2 canaux)
 *  - Buzzer actif 5V
 *  - LED RGB ou 3 LEDs (Vert/Orange/Rouge)
 *  - Clavier 4x4 matriciel (pour saisie PIN)
 *  - Optionnel : écran TFT SPI ILI9341 (ou OLED 128x64)
 *
 * LIBRAIRIES ARDUINO À INSTALLER :
 *  - MFRC522 by GithubCommunity
 *  - ArduinoJson by Benoit Blanchon
 *  - HTTPClient (inclus dans ESP32 Arduino Core)
 *  - Keypad by Mark Stanley
 * ============================================================
 */

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Keypad.h>

// ============================================================
// CONFIGURATION — À MODIFIER SELON VOTRE INSTALLATION
// ============================================================

// --- WiFi ---
const char* WIFI_SSID     = "VOTRE_WIFI_SSID";
const char* WIFI_PASSWORD = "VOTRE_WIFI_PASSWORD";

// --- Serveur API ---
const char* SERVER_BASE   = "http://192.168.1.100/water/public/index.php";
// Remplacez par l'IP de votre serveur Laragon
// Ex : "http://192.168.1.50/water/public/index.php"

const int   BORNE_ID      = 1;       // ID de cette borne dans la DB
const int   WIFI_TIMEOUT  = 15000;   // Timeout connexion WiFi (ms)
const int   HTTP_TIMEOUT  = 8000;    // Timeout requête HTTP (ms)
const int   PING_INTERVAL = 30000;   // Intervalle keep-alive (30s)

// --- Paramètres de distribution ---
const float PULSES_PER_LITRE   = 10.0;    // Impulsions par litre (à calibrer)
const float DEBIT_MIN_L_MIN    = 5.0;     // Débit minimum normal (L/min)
const float DEBIT_MAX_L_MIN    = 200.0;   // Débit max avant alerte fuite (L/min)
const float FUITE_SEUIL_LITRES = 2.0;     // Litres perdus avant alerte fuite
const int   MANQUE_EAU_TIMEOUT = 10000;   // Timeout sans débit = manque eau (ms)
const int   VOLUME_MAX_LITRES  = 2000;    // Volume max par transaction (L)

// ============================================================
// BROCHES (PINS)
// ============================================================

// RFID MFRC522 — SPI
#define PIN_RFID_SS     5
#define PIN_RFID_RST    27
// SCK=18, MOSI=23, MISO=19 (broches SPI ESP32 par défaut)

// Débitmètre (entrée impulsion interrupt)
#define PIN_FLOW_METER  34   // GPIO 34 — entrée seule (INPUT_PULLUP non dispo, utiliser R externe)

// Électrovanne (via relais — LOW = ouvert, HIGH = fermé)
#define PIN_VALVE       26   // GPIO 26 → Relais electrovanne

// Capteurs de sécurité
#define PIN_OVERFLOW    35   // GPIO 35 — Flotteur trop-plein (HIGH = trop-plein)
#define PIN_LEAK_SENSOR 33   // GPIO 33 — Sonde fuite sol (HIGH = fuite détectée)

// Signalisation
#define PIN_BUZZER      32   // GPIO 32 — Buzzer actif
#define PIN_LED_GREEN   25   // GPIO 25 — LED verte (prêt / succès)
#define PIN_LED_ORANGE  14   // GPIO 14 — LED orange (en cours)
#define PIN_LED_RED     12   // GPIO 12 — LED rouge (erreur / alerte)

// Clavier 4x4 (pour saisie PIN)
const byte ROWS = 4;
const byte COLS = 4;
char hexaKeys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {13, 2, 0, 4};   // Lignes clavier
byte colPins[COLS] = {16, 17, 5, 18}; // Colonnes clavier
// Attention : ajuster si conflit avec SPI. Vérifier le pinout de votre ESP32.

// ============================================================
// OBJETS GLOBAUX
// ============================================================

MFRC522 rfid(PIN_RFID_SS, PIN_RFID_RST);
Keypad  keypad = Keypad(makeKeymap(hexaKeys), rowPins, colPins, ROWS, COLS);

// ============================================================
// VARIABLES VOLATILES (ISR débitmètre)
// ============================================================

volatile unsigned long pulseCount     = 0;
unsigned long          lastPulseCount = 0;
unsigned long          lastFlowCheck  = 0;

// ============================================================
// MACHINE À ÉTATS
// ============================================================

enum State {
  STATE_IDLE,           // Attente scan carte
  STATE_VERIFYING,      // Vérification carte en cours
  STATE_PIN_WAIT,       // Attente saisie PIN
  STATE_PIN_VERIFYING,  // Vérification PIN en cours
  STATE_VOLUME_SELECT,  // Sélection volume (clavier)
  STATE_DISTRIBUTING,   // Distribution eau en cours
  STATE_DONE,           // Distribution terminée
  STATE_ERROR,          // Erreur
  STATE_ALERT           // Alerte sécurité active
};

State currentState = STATE_IDLE;

// ============================================================
// DONNÉES SESSION
// ============================================================

struct Session {
  String  cardUID;
  String  farmerName;
  float   solde;
  float   pricePerLitre;
  float   maxVolumeLitres;
  bool    hasPin;
  float   requestedLitres;
  float   distributedLitres;
  float   debitedAmount;
  unsigned long startTime;
  unsigned long lastFlowTime;
};

Session session;

// ============================================================
// TIMERS
// ============================================================

unsigned long lastPingTime     = 0;
unsigned long stateEnterTime   = 0;
unsigned long lastStatusDisplay = 0;

String pinBuffer = "";
bool   alertSent = false;

// ============================================================
// ISR : DÉBITMÈTRE
// ============================================================

void IRAM_ATTR onFlowPulse() {
  pulseCount++;
}

// ============================================================
// SETUP
// ============================================================

void setup() {
  Serial.begin(115200);
  Serial.println(F("\n========================================"));
  Serial.println(F("  BORNE RFID EAU — ESP32 v2.0"));
  Serial.println(F("========================================"));

  // Broches
  pinMode(PIN_VALVE,       OUTPUT);
  pinMode(PIN_BUZZER,      OUTPUT);
  pinMode(PIN_LED_GREEN,   OUTPUT);
  pinMode(PIN_LED_ORANGE,  OUTPUT);
  pinMode(PIN_LED_RED,     OUTPUT);
  pinMode(PIN_OVERFLOW,    INPUT_PULLDOWN);
  pinMode(PIN_LEAK_SENSOR, INPUT_PULLDOWN);

  // Sécurité : vanne FERMÉE au démarrage
  valveClose();
  ledsOff();

  // SPI + RFID
  SPI.begin();
  rfid.PCD_Init();
  Serial.println(F("[RFID] Lecteur initialisé"));

  // Interrupt débitmètre
  // GPIO 34 ne supporte pas INPUT_PULLUP — mettre résistance externe 10kΩ vers 3.3V
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW_METER), onFlowPulse, FALLING);

  // WiFi
  connectWiFi();

  // Bip de démarrage
  beep(3, 100);
  setLed(GREEN);
  Serial.println(F("[SYS] Borne prête — En attente d'une carte RFID...\n"));
}

// ============================================================
// LOOP PRINCIPALE
// ============================================================

void loop() {
  unsigned long now = millis();

  // --- Keep-alive ping serveur ---
  if (now - lastPingTime > PING_INTERVAL) {
    pingServer();
    lastPingTime = now;
  }

  // --- Reconnexion WiFi si perdue ---
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println(F("[WIFI] Connexion perdue — tentative de reconnexion..."));
    // Si distribution en cours : arrêt d'urgence
    if (currentState == STATE_DISTRIBUTING) {
      emergencyStop("Perte de communication WiFi");
    }
    connectWiFi();
  }

  // --- Vérifications de sécurité (toujours actives) ---
  checkSafety();

  // --- Machine à états ---
  switch (currentState) {

    case STATE_IDLE:
      handleIdle();
      break;

    case STATE_PIN_WAIT:
      handlePinWait();
      break;

    case STATE_VOLUME_SELECT:
      handleVolumeSelect();
      break;

    case STATE_DISTRIBUTING:
      handleDistributing();
      break;

    case STATE_DONE:
      handleDone();
      break;

    case STATE_ERROR:
      handleError();
      break;

    case STATE_ALERT:
      // Attendre que l'opérateur réinitialise manuellement
      if (now - stateEnterTime > 60000) {
        resetSession();
      }
      break;

    default:
      break;
  }

  // --- Affichage statut série toutes les 5s ---
  if (now - lastStatusDisplay > 5000 && currentState == STATE_DISTRIBUTING) {
    float litres = pulsesToLitres(pulseCount - lastPulseCount);
    Serial.printf("[DIST] Volume distribué : %.2f / %.2f L\n",
                  session.distributedLitres + litres, session.requestedLitres);
    lastStatusDisplay = now;
  }
}

// ============================================================
// ÉTAT IDLE — Attente carte RFID
// ============================================================

void handleIdle() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    return;
  }

  // Lire UID
  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  Serial.println(F("\n--- CARTE SCANNÉE ---"));
  Serial.println("[RFID] UID: " + uid);
  beep(1, 200);
  setLed(ORANGE);

  // Initialiser session
  session = Session();
  session.cardUID  = uid;
  pinBuffer        = "";
  alertSent        = false;
  currentState     = STATE_VERIFYING;
  stateEnterTime   = millis();

  // Appel API verify
  verifyCard(uid);
}

// ============================================================
// APPEL API : Vérifier carte
// ============================================================

void verifyCard(const String& uid) {
  String url = String(SERVER_BASE) + "?route=api/cards/verify&uid=" + uid
               + "&borne_id=" + BORNE_ID;

  JsonDocument response;
  bool ok = httpGet(url, response);

  if (!ok || response["status"] != "success") {
    String msg = response["message"] | "Carte invalide ou refusée.";
    Serial.println("[API] Erreur verify: " + msg);
    displayMessage("CARTE REFUSÉE", msg);
    beep(2, 400);
    setLed(RED);
    delay(3000);
    resetSession();
    return;
  }

  // Lecture des données de la carte
  session.farmerName     = response["card"]["farmer_prenom"].as<String>()
                           + " " + response["card"]["farmer_nom"].as<String>();
  session.solde          = response["card"]["solde"];
  session.pricePerLitre  = response["price_per_litre"];
  session.maxVolumeLitres = response["max_volume_litres"];
  session.hasPin         = response["has_pin"];

  Serial.println("[API] Carte OK — " + session.farmerName);
  Serial.printf("[API] Solde: %.3f DT | Max: %.1f L\n",
                session.solde, session.maxVolumeLitres);

  if (session.hasPin) {
    // Passer à la saisie PIN
    Serial.println(F("[SYS] Carte PIN requise → saisie PIN"));
    displayMessage("CODE PIN", "Entrez votre code PIN à 4 chiffres :");
    pinBuffer    = "";
    currentState = STATE_PIN_WAIT;
    stateEnterTime = millis();
    setLed(ORANGE);
  } else {
    // Pas de PIN → sélection volume
    displayWelcome();
    currentState = STATE_VOLUME_SELECT;
    stateEnterTime = millis();
    setLed(GREEN);
  }
}

// ============================================================
// ÉTAT PIN_WAIT — Saisie du code PIN
// ============================================================

void handlePinWait() {
  // Timeout 30 secondes sans saisie
  if (millis() - stateEnterTime > 30000) {
    Serial.println(F("[PIN] Timeout saisie PIN"));
    displayMessage("TIMEOUT", "Délai de saisie dépassé.");
    beep(2, 300);
    delay(2000);
    resetSession();
    return;
  }

  char key = keypad.getKey();
  if (!key) return;

  if (key == '#') {
    // Annuler
    Serial.println(F("[PIN] Annulation par l'utilisateur"));
    displayMessage("ANNULÉ", "Opération annulée.");
    delay(1500);
    resetSession();
    return;
  }

  if (key == '*') {
    // Effacer dernier chiffre
    if (pinBuffer.length() > 0) {
      pinBuffer = pinBuffer.substring(0, pinBuffer.length() - 1);
    }
    displayPinProgress(pinBuffer.length());
    return;
  }

  if (key >= '0' && key <= '9') {
    if (pinBuffer.length() < 4) {
      pinBuffer += key;
      beep(1, 50);
      displayPinProgress(pinBuffer.length());

      if (pinBuffer.length() == 4) {
        // PIN complet → vérification
        Serial.println(F("[PIN] PIN saisi → vérification..."));
        currentState = STATE_PIN_VERIFYING;
        stateEnterTime = millis();
        verifyPin();
      }
    }
  }
}

// ============================================================
// APPEL API : Vérifier PIN
// ============================================================

void verifyPin() {
  String url = String(SERVER_BASE) + "?route=api/cards/verify-pin"
               + "&uid=" + session.cardUID
               + "&pin=" + pinBuffer
               + "&borne_id=" + BORNE_ID;

  JsonDocument response;
  bool ok = httpGet(url, response);

  if (!ok || response["status"] != "success") {
    String msg = response["message"] | "Code PIN incorrect.";
    Serial.println("[API] PIN refusé: " + msg);
    displayMessage("PIN INCORRECT", msg);
    beep(3, 300);
    setLed(RED);
    delay(3000);
    // Retour saisie PIN (avec buffer vide)
    pinBuffer      = "";
    currentState   = STATE_PIN_WAIT;
    stateEnterTime = millis();
    setLed(ORANGE);
    displayMessage("CODE PIN", "Réessayez votre code PIN :");
    return;
  }

  // Mettre à jour les données post-PIN (le serveur retourne les vraies valeurs)
  session.solde           = response["card"]["solde"];
  session.pricePerLitre   = response["price_per_litre"];
  session.maxVolumeLitres = response["max_volume_litres"];

  Serial.println("[API] PIN OK → Sélection volume");
  beep(1, 200);
  displayWelcome();
  currentState   = STATE_VOLUME_SELECT;
  stateEnterTime = millis();
  setLed(GREEN);
}

// ============================================================
// ÉTAT VOLUME_SELECT — Sélection quantité via clavier
// ============================================================

void handleVolumeSelect() {
  // Timeout 60 secondes
  if (millis() - stateEnterTime > 60000) {
    Serial.println(F("[SYS] Timeout sélection volume"));
    displayMessage("TIMEOUT", "Aucune sélection effectuée.");
    delay(2000);
    resetSession();
    return;
  }

  static String volumeBuffer = "";

  // Afficher instruction
  if (millis() - stateEnterTime < 200) {
    Serial.println(F("[SYS] Saisissez le volume en litres puis appuyez sur # :"));
    Serial.println(F("        A = Remplissage complet | # = Valider | * = Effacer"));
    displayVolumePrompt();
  }

  char key = keypad.getKey();
  if (!key) return;

  if (key == 'A') {
    // Remplissage complet (max solde)
    session.requestedLitres = session.maxVolumeLitres;
    volumeBuffer = "";
    Serial.printf("[SYS] Remplissage complet: %.1f L\n", session.requestedLitres);
    startDistribution();
    return;
  }

  if (key == '#') {
    // Valider volume saisi
    if (volumeBuffer.length() > 0) {
      float vol = volumeBuffer.toFloat();
      if (vol <= 0 || vol > session.maxVolumeLitres) {
        displayMessage("VOLUME INVALIDE",
          "Max: " + String(session.maxVolumeLitres, 1) + " L");
        beep(2, 200);
        delay(2000);
        volumeBuffer = "";
        displayVolumePrompt();
        return;
      }
      session.requestedLitres = vol;
      volumeBuffer = "";
      Serial.printf("[SYS] Volume demandé: %.1f L\n", session.requestedLitres);
      startDistribution();
    }
    return;
  }

  if (key == '*') {
    // Effacer
    if (volumeBuffer.length() > 0)
      volumeBuffer = volumeBuffer.substring(0, volumeBuffer.length() - 1);
    Serial.println("[VOL] Saisie: " + volumeBuffer + " L");
    return;
  }

  if (key >= '0' && key <= '9') {
    if (volumeBuffer.length() < 6) {
      volumeBuffer += key;
      beep(1, 50);
      Serial.println("[VOL] Saisie: " + volumeBuffer + " L");
    }
  }

  if (key == 'B') {
    // Préréglages (50L, 100L, 200L, 500L)
    static const int presets[] = {50, 100, 200, 500};
    static int presetIdx = 0;
    float vol = min((float)presets[presetIdx % 4], session.maxVolumeLitres);
    session.requestedLitres = vol;
    presetIdx++;
    volumeBuffer = "";
    Serial.printf("[VOL] Préréglage: %.1f L\n", vol);
    startDistribution();
  }
}

// ============================================================
// DÉMARRAGE DISTRIBUTION
// ============================================================

void startDistribution() {
  Serial.println(F("\n--- DÉBUT DISTRIBUTION ---"));
  Serial.printf("[DIST] Volume demandé : %.1f L\n", session.requestedLitres);
  Serial.printf("[DIST] Solde : %.3f DT | Prix : %.3f DT/L\n",
                session.solde, session.pricePerLitre);

  // Réinitialiser compteur impulsions
  noInterrupts();
  lastPulseCount = pulseCount;
  interrupts();

  session.distributedLitres = 0;
  session.debitedAmount     = 0;
  session.startTime         = millis();
  session.lastFlowTime      = millis();

  // Ouvrir vanne
  valveOpen();
  setLed(GREEN);
  beep(1, 100);
  displayDistribution();

  currentState   = STATE_DISTRIBUTING;
  stateEnterTime = millis();
}

// ============================================================
// ÉTAT DISTRIBUTING — Distribution en cours
// ============================================================

void handleDistributing() {
  unsigned long now = millis();

  // Calculer le volume distribué depuis le démarrage
  unsigned long currentPulses;
  noInterrupts();
  currentPulses = pulseCount;
  interrupts();

  unsigned long delta        = currentPulses - lastPulseCount;
  float         distributed  = pulsesToLitres(delta);
  session.distributedLitres  = distributed;

  // --- Vérification débit (protection manque d'eau) ---
  if (distributed > 0.01) {
    session.lastFlowTime = now; // Il y a du débit
  } else if (now - session.lastFlowTime > MANQUE_EAU_TIMEOUT) {
    // Aucun débit depuis MANQUE_EAU_TIMEOUT → manque d'eau
    valveClose();
    sendAlert("manque_eau",
      "Débit nul détecté pendant " + String(MANQUE_EAU_TIMEOUT / 1000) + "s. "
      "Possible manque d'eau ou blocage.");
    displayMessage("MANQUE D'EAU", "Arrêt automatique — Appelez l'opérateur.");
    beep(5, 300);
    setLed(RED);
    finalizeTransaction("interrompue_erreur");
    currentState   = STATE_ALERT;
    stateEnterTime = now;
    return;
  }

  // --- Volume atteint ? ---
  if (distributed >= session.requestedLitres) {
    valveClose();
    session.distributedLitres = session.requestedLitres; // Normaliser
    beep(3, 200);
    setLed(GREEN);
    finalizeTransaction("reussie");
    displaySuccess();
    currentState   = STATE_DONE;
    stateEnterTime = now;
    return;
  }

  // Mise à jour affichage toutes les 500ms
  static unsigned long lastDisplay = 0;
  if (now - lastDisplay > 500) {
    displayDistributionProgress(distributed, session.requestedLitres);
    lastDisplay = now;
  }
}

// ============================================================
// ÉTAT DONE — Afficher récapitulatif
// ============================================================

void handleDone() {
  // Rester affiché 10 secondes puis retour IDLE
  if (millis() - stateEnterTime > 10000) {
    resetSession();
  }
}

// ============================================================
// ÉTAT ERROR
// ============================================================

void handleError() {
  if (millis() - stateEnterTime > 5000) {
    resetSession();
  }
}

// ============================================================
// VÉRIFICATIONS SÉCURITÉ (appelées à chaque loop)
// ============================================================

void checkSafety() {
  if (currentState != STATE_DISTRIBUTING) return;

  // --- Trop-plein ---
  if (digitalRead(PIN_OVERFLOW) == HIGH) {
    valveClose();
    sendAlert("trop_plein", "Capteur de trop-plein activé. Arrêt immédiat de la distribution.");
    displayMessage("TROP-PLEIN !", "Arrêt d'urgence — Réservoir plein.");
    beep(10, 150);
    setLed(RED);
    finalizeTransaction("interrompue_erreur");
    currentState   = STATE_ALERT;
    stateEnterTime = millis();
    return;
  }

  // --- Fuite capteur sol ---
  if (digitalRead(PIN_LEAK_SENSOR) == HIGH) {
    valveClose();
    sendAlert("fuite",
      "Sonde de fuite sol activée sur borne #" + String(BORNE_ID) + ". "
      "Arrêt préventif de la distribution.");
    displayMessage("FUITE DÉTECTÉE", "Arrêt d'urgence — Contactez la maintenance.");
    beep(10, 100);
    setLed(RED);
    finalizeTransaction("interrompue_erreur");
    currentState   = STATE_ALERT;
    stateEnterTime = millis();
    return;
  }

  // --- Détection fuite par débit anormal ---
  // (débit mesuré dépasse largement le débit théorique d'une DN100)
  unsigned long now = millis();
  if (now - lastFlowCheck > 1000) {
    unsigned long currentPulses;
    noInterrupts();
    currentPulses = pulseCount;
    interrupts();

    unsigned long pulsesInSec = currentPulses - lastPulseCount;
    float  debitLMin          = pulsesToLitres(pulsesInSec) * 60.0;
    lastPulseCount            = currentPulses;
    lastFlowCheck             = now;

    if (debitLMin > DEBIT_MAX_L_MIN && !alertSent) {
      alertSent = true;
      sendAlert("fuite",
        "Débit anormal : " + String(debitLMin, 1) + " L/min "
        "(seuil : " + String(DEBIT_MAX_L_MIN, 0) + " L/min). "
        "Possible rupture de conduite.");
      // Note : on ne coupe pas automatiquement, mais on alerte
    }
  }
}

// ============================================================
// FINALISATION TRANSACTION
// ============================================================

void finalizeTransaction(const String& statut) {
  float cost = session.distributedLitres * session.pricePerLitre;
  session.debitedAmount = cost;

  Serial.println(F("\n--- FIN DISTRIBUTION ---"));
  Serial.printf("[TX] Volume distribué : %.2f L\n", session.distributedLitres);
  Serial.printf("[TX] Montant débité   : %.3f DT\n", cost);
  Serial.printf("[TX] Statut           : %s\n", statut.c_str());

  // Envoyer la transaction au serveur
  String url = String(SERVER_BASE) + "?route=api/transactions/store";

  JsonDocument body;
  body["borne_id"]         = BORNE_ID;
  body["uid"]              = session.cardUID;
  body["volume_demande"]   = session.requestedLitres;
  body["volume_distribue"] = session.distributedLitres;
  body["statut"]           = statut;

  String jsonStr;
  serializeJson(body, jsonStr);

  JsonDocument response;
  bool ok = httpPost(url, jsonStr, response);

  if (ok && response["status"] == "success") {
    float newBalance = response["nouveau_solde"];
    Serial.printf("[TX] ✓ Transaction OK | Nouveau solde : %.3f DT\n", newBalance);
  } else {
    Serial.println("[TX] ✗ Erreur enregistrement transaction");
    Serial.println("[TX] " + response["message"].as<String>());
    // Conserver en mémoire locale si nécessaire (SPIFFS)
  }
}

// ============================================================
// ENVOI ALERTE
// ============================================================

void sendAlert(const String& type, const String& description) {
  Serial.println("[ALERT] " + type + " — " + description);

  String url  = String(SERVER_BASE) + "?route=api/alertes/store";

  JsonDocument body;
  body["borne_id"]    = BORNE_ID;
  body["type_alerte"] = type;
  body["description"] = description;

  String jsonStr;
  serializeJson(body, jsonStr);

  JsonDocument response;
  httpPost(url, jsonStr, response);
}

// ============================================================
// PING SERVEUR (KEEP-ALIVE)
// ============================================================

void pingServer() {
  String url = String(SERVER_BASE) + "?route=api/bornes/ping&borne_id=" + BORNE_ID;
  JsonDocument response;
  bool ok = httpGet(url, response);
  Serial.println(ok ? "[PING] ✓ Serveur OK" : "[PING] ✗ Serveur injoignable");
}

// ============================================================
// ARRÊT D'URGENCE
// ============================================================

void emergencyStop(const String& reason) {
  valveClose();
  Serial.println("[URGENCE] " + reason);
  beep(5, 200);
  setLed(RED);
  if (session.distributedLitres > 0.01) {
    finalizeTransaction("interrompue_erreur");
  }
  sendAlert("com_perdue", reason);
  resetSession();
}

// ============================================================
// UTILITAIRES — VANNE
// ============================================================

void valveOpen()  {
  digitalWrite(PIN_VALVE, LOW);  // Relais NC → activer = ouvrir
  Serial.println(F("[VANNE] Ouverte"));
}
void valveClose() {
  digitalWrite(PIN_VALVE, HIGH); // Relais NC → désactiver = fermer
  Serial.println(F("[VANNE] Fermée"));
}

// ============================================================
// UTILITAIRES — CALCULS DÉBIT
// ============================================================

float pulsesToLitres(unsigned long pulses) {
  return (float)pulses / PULSES_PER_LITRE;
}

// ============================================================
// UTILITAIRES — LEDS
// ============================================================

enum Color { GREEN, ORANGE, RED, OFF };

void setLed(Color c) {
  digitalWrite(PIN_LED_GREEN,  c == GREEN  ? HIGH : LOW);
  digitalWrite(PIN_LED_ORANGE, c == ORANGE ? HIGH : LOW);
  digitalWrite(PIN_LED_RED,    c == RED    ? HIGH : LOW);
}
void ledsOff() { setLed(OFF); }

// ============================================================
// UTILITAIRES — BUZZER
// ============================================================

void beep(int count, int durationMs) {
  for (int i = 0; i < count; i++) {
    digitalWrite(PIN_BUZZER, HIGH);
    delay(durationMs);
    digitalWrite(PIN_BUZZER, LOW);
    if (i < count - 1) delay(durationMs / 2);
  }
}

// ============================================================
// UTILITAIRES — RÉINITIALISATION SESSION
// ============================================================

void resetSession() {
  valveClose();
  ledsOff();
  session      = Session();
  pinBuffer    = "";
  alertSent    = false;
  currentState = STATE_IDLE;
  setLed(GREEN);
  Serial.println(F("\n[SYS] Session réinitialisée — En attente carte...\n"));
  displayIdle();
}

// ============================================================
// AFFICHAGE SÉRIE (Remplacer par écran TFT si dispo)
// ============================================================

void displayIdle() {
  Serial.println(F("┌────────────────────────────────┐"));
  Serial.println(F("│   BORNE EAU — PRÊTE            │"));
  Serial.println(F("│   Approchez votre carte RFID   │"));
  Serial.println(F("└────────────────────────────────┘"));
}

void displayWelcome() {
  Serial.println(F("┌────────────────────────────────┐"));
  Serial.println("│ Bienvenue " + session.farmerName);
  Serial.printf("│ Solde : %.3f DT\n", session.solde);
  Serial.printf("│ Max   : %.1f L\n", session.maxVolumeLitres);
  Serial.println(F("└────────────────────────────────┘"));
}

void displayVolumePrompt() {
  Serial.printf("[VOL] Solde: %.3f DT | Max: %.1f L\n",
                session.solde, session.maxVolumeLitres);
  Serial.println(F("[VOL] Saisir volume (L) puis # | A=Max | B=Préréglage"));
}

void displayPinProgress(int digits) {
  Serial.print("[PIN] Code: ");
  for (int i = 0; i < 4; i++) Serial.print(i < digits ? "*" : "-");
  Serial.println();
}

void displayDistribution() {
  Serial.println(F("┌────────────────────────────────┐"));
  Serial.printf("│ Distribution : %.1f L\n", session.requestedLitres);
  Serial.println(F("│ Vanne : OUVERTE                │"));
  Serial.println(F("└────────────────────────────────┘"));
}

void displayDistributionProgress(float done, float total) {
  float pct = (total > 0) ? (done / total * 100.0) : 0;
  Serial.printf("[DIST] %.2f / %.2f L (%.0f%%)\n", done, total, pct);
}

void displaySuccess() {
  Serial.println(F("┌────────────────────────────────┐"));
  Serial.println(F("│         ✓ SUCCÈS               │"));
  Serial.printf("│ Distribué : %.2f L\n", session.distributedLitres);
  Serial.printf("│ Débité    : %.3f DT\n", session.debitedAmount);
  Serial.println(F("│ Merci !                        │"));
  Serial.println(F("└────────────────────────────────┘"));
}

void displayMessage(const String& title, const String& msg) {
  Serial.println("┌── " + title + " ──");
  Serial.println("│ " + msg);
  Serial.println(F("└────────────────────────────────"));
}

// ============================================================
// HTTP — GET
// ============================================================

bool httpGet(const String& url, JsonDocument& response) {
  if (WiFi.status() != WL_CONNECTED) return false;

  HTTPClient http;
  http.begin(url);
  http.setTimeout(HTTP_TIMEOUT);
  http.addHeader("Accept", "application/json");

  int code = http.GET();
  if (code <= 0) {
    Serial.println("[HTTP] GET erreur: " + http.errorToString(code));
    http.end();
    return false;
  }

  String body = http.getString();
  http.end();

  DeserializationError err = deserializeJson(response, body);
  if (err) {
    Serial.println("[HTTP] JSON parse erreur: " + String(err.c_str()));
    return false;
  }
  return true;
}

// ============================================================
// HTTP — POST (JSON)
// ============================================================

bool httpPost(const String& url, const String& jsonBody, JsonDocument& response) {
  if (WiFi.status() != WL_CONNECTED) return false;

  HTTPClient http;
  http.begin(url);
  http.setTimeout(HTTP_TIMEOUT);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Accept", "application/json");

  int code = http.POST(jsonBody);
  if (code <= 0) {
    Serial.println("[HTTP] POST erreur: " + http.errorToString(code));
    http.end();
    return false;
  }

  String body = http.getString();
  http.end();

  DeserializationError err = deserializeJson(response, body);
  if (err) {
    Serial.println("[HTTP] JSON parse erreur: " + String(err.c_str()));
    return false;
  }
  return true;
}

// ============================================================
// WiFi — Connexion avec retry
// ============================================================

void connectWiFi() {
  Serial.print("[WIFI] Connexion à ");
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long start = millis();
  int dots = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    dots++;
    if (millis() - start > WIFI_TIMEOUT) {
      Serial.println(F("\n[WIFI] Timeout — Mode hors-ligne (fonctions limitées)"));
      setLed(ORANGE);
      return;
    }
  }

  Serial.println();
  Serial.print("[WIFI] Connecté — IP : ");
  Serial.println(WiFi.localIP());
  setLed(GREEN);
}
