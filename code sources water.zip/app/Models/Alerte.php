<?php

namespace App\Models;

use PDO;

/**
 * Modèle Alerte
 * Gère l'historique et la résolution des incidents de sécurité (fuites, trop-plein, etc.).
 */
class Alerte extends BaseModel {
    /**
     * Récupère toutes les alertes avec les infos de la borne émettrice.
     */
    public function findAll(): array {
        $sql = "SELECT a.*, b.nom AS borne_nom 
                FROM alertes a
                JOIN bornes b ON a.borne_id = b.id
                ORDER BY a.resolu ASC, a.date_heure DESC";
        return $this->db->query($sql)->fetchAll();
    }

    /**
     * Crée une nouvelle alerte de sécurité.
     */
    public function insert(array $data): bool {
        $stmt = $this->db->prepare(
            "INSERT INTO alertes (borne_id, type_alerte, description) 
             VALUES (:borne_id, :type_alerte, :description)"
        );
        return $stmt->execute([
            'borne_id'    => $data['borne_id'],
            'type_alerte' => $data['type_alerte'],
            'description' => $data['description']
        ]);
    }

    /**
     * Marque une alerte comme résolue.
     */
    public function resolve(int $id): bool {
        $stmt = $this->db->prepare("UPDATE alertes SET resolu = 1 WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }

    /**
     * Compte le nombre d'alertes actives (non résolues).
     */
    public function countActive(): int {
        return (int) $this->db->query("SELECT COUNT(*) FROM alertes WHERE resolu = 0")->fetchColumn();
    }
}
