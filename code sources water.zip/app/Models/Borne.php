<?php

namespace App\Models;

use PDO;

/**
 * Modèle Borne
 * Gère les bornes physiques de distribution et leur supervision.
 */
class Borne extends BaseModel {
    /**
     * Récupère toutes les bornes.
     */
    public function findAll(): array {
        $stmt = $this->db->query("SELECT * FROM bornes ORDER BY nom ASC");
        return $stmt->fetchAll();
    }

    /**
     * Recherche une borne par son ID.
     */
    public function find(int $id) {
        $stmt = $this->db->prepare("SELECT * FROM bornes WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Met à jour le ping de la borne (mise en ligne).
     */
    public function ping(int $id): bool {
        $stmt = $this->db->prepare(
            "UPDATE bornes 
             SET statut_connexion = 'en ligne', dernier_ping = CURRENT_TIMESTAMP 
             WHERE id = :id"
        );
        return $stmt->execute(['id' => $id]);
    }

    /**
     * Compte les bornes en fonction de leur statut.
     */
    public function count(string $statut = null): int {
        if ($statut) {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM bornes WHERE statut_connexion = :statut");
            $stmt->execute(['statut' => $statut]);
        } else {
            $stmt = $this->db->query("SELECT COUNT(*) FROM bornes");
        }
        return (int) $stmt->fetchColumn();
    }
}
