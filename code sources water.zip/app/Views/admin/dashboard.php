<?php
// Rôles et permissions de l'administrateur connecté
$isAdmin = isset($currentAdmin) && $currentAdmin['role'] === 'admin';
$viewClients = $isAdmin || (isset($currentAdmin) && (bool)$currentAdmin['perm_view_clients']);
$viewBalances = $isAdmin || (isset($currentAdmin) && (bool)$currentAdmin['perm_view_balances']);
$viewTransactions = $isAdmin || (isset($currentAdmin) && (bool)$currentAdmin['perm_view_transactions']);
$manageClients = $isAdmin || (isset($currentAdmin) && (bool)$currentAdmin['perm_manage_clients']);
$canRecharge = $isAdmin || (isset($currentAdmin) && (bool)$currentAdmin['perm_can_recharge']);
?>

<!-- En-tête du Tableau de Bord -->
<div class="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
    <div>
        <h1 class="text-2xl font-bold bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">Tableau de Bord Administration</h1>
        <p class="text-xs text-slate-400 mt-1">Supervision globale et configuration du réseau de distribution d'eau RFID.</p>
    </div>
    <!-- État de connexion des bornes -->
    <div class="flex items-center gap-3 bg-slate-900/60 border border-slate-800/80 px-4 py-2.5 rounded-2xl self-start">
        <i data-lucide="radio" class="w-5 h-5 text-cyan-400"></i>
        <div class="text-xs">
            <span class="font-semibold block text-slate-200"><?= $stats['online_bornes'] ?> / <?= $stats['total_bornes'] ?> Bornes en ligne</span>
            <span class="text-slate-500">Supervision en temps réel</span>
        </div>
    </div>
</div>

<!-- Onglets de Navigation style premium -->
<nav class="flex border-b border-slate-800 gap-6 mb-8">
    <a href="#supervision" onclick="switchTab('supervision')" id="tab-btn-supervision" class="tab-btn pb-4 px-1 font-semibold text-sm transition-all duration-300 border-b-2 flex items-center gap-2 text-blue-400 border-blue-500">
        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
        Activité &amp; Supervision
    </a>
    <?php if ($isAdmin): ?>
        <a href="#config" onclick="switchTab('config')" id="tab-btn-config" class="tab-btn pb-4 px-1 font-semibold text-sm transition-all duration-300 border-b-2 flex items-center gap-2 text-slate-400 border-transparent hover:text-slate-200">
            <i data-lucide="settings" class="w-4 h-4"></i>
            Paramètres Système
        </a>
        <a href="#users" onclick="switchTab('users')" id="tab-btn-users" class="tab-btn pb-4 px-1 font-semibold text-sm transition-all duration-300 border-b-2 flex items-center gap-2 text-slate-400 border-transparent hover:text-slate-200">
            <i data-lucide="shield-check" class="w-4 h-4"></i>
            Comptes &amp; Accès
        </a>
    <?php endif; ?>
</nav>

<!-- ==================================================== -->
<!-- ONGLET 1: ACTIVITÉ & SUPERVISION                     -->
<!-- ==================================================== -->
<div id="tab-supervision" class="tab-content block">
    
    <!-- Section des Indicateurs Clés -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Volume Total -->
        <div class="glass-card rounded-2xl p-6 relative overflow-hidden group hover:border-blue-500/20 transition-all duration-300">
            <div class="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all duration-300"></div>
            <div class="flex items-center justify-between mb-4">
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Volume Distribué</span>
                <div class="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
                    <i data-lucide="droplet" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-2xl font-extrabold tracking-tight"><?= number_format($stats['total_volume'], 1) ?></span>
                <span class="text-sm font-medium text-slate-500">Litres</span>
            </div>
        </div>

        <!-- Revenus / Crédits Consommés -->
        <?php if ($viewBalances): ?>
            <div class="glass-card rounded-2xl p-6 relative overflow-hidden group hover:border-cyan-500/20 transition-all duration-300">
                <div class="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-all duration-300"></div>
                <div class="flex items-center justify-between mb-4">
                    <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Crédits Débités</span>
                    <div class="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                        <i data-lucide="coins" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="flex items-baseline gap-1">
                    <span class="text-2xl font-extrabold tracking-tight"><?= number_format($stats['total_revenue'], 3) ?></span>
                    <span class="text-sm font-medium text-slate-500">DT</span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Cartes Actives -->
        <?php if ($viewClients): ?>
            <div class="glass-card rounded-2xl p-6 relative overflow-hidden group hover:border-indigo-500/20 transition-all duration-300">
                <div class="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl group-hover:bg-indigo-500/10 transition-all duration-300"></div>
                <div class="flex items-center justify-between mb-4">
                    <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Cartes RFID Actives</span>
                    <div class="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                        <i data-lucide="credit-card" class="w-4 h-4"></i>
                    </div>
                </div>
                <div class="flex items-baseline gap-2">
                    <span class="text-2xl font-extrabold tracking-tight"><?= $stats['active_cards'] ?></span>
                    <span class="text-sm font-medium text-slate-500">cartes</span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Alertes Actives -->
        <div class="glass-card rounded-2xl p-6 relative overflow-hidden group hover:border-red-500/20 transition-all duration-300">
            <div class="absolute top-0 right-0 w-24 h-24 bg-red-500/5 rounded-full blur-2xl group-hover:bg-red-500/10 transition-all duration-300"></div>
            <div class="flex items-center justify-between mb-4">
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Alertes Actives</span>
                <div class="w-9 h-9 rounded-xl <?= $stats['active_alerts'] > 0 ? 'bg-red-500/20 text-red-400 animate-pulse' : 'bg-slate-500/10 text-slate-400' ?> flex items-center justify-center">
                    <i data-lucide="alert-triangle" class="w-4 h-4"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-2xl font-extrabold tracking-tight <?= $stats['active_alerts'] > 0 ? 'text-red-400' : '' ?>"><?= $stats['active_alerts'] ?></span>
                <span class="text-sm font-medium text-slate-500">incidents</span>
            </div>
        </div>
    </div>

    <!-- Section Principale : Tableau et Alertes -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <!-- Historique des Transactions -->
        <?php if ($viewTransactions): ?>
            <div class="glass-card rounded-2xl p-6 lg:col-span-2 flex flex-col">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-lg font-bold text-slate-200 flex items-center gap-2">
                        <i data-lucide="history" class="w-5 h-5 text-blue-400"></i>
                        Consommations Récentes (Bornes)
                    </h2>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b border-slate-800 text-xs font-semibold uppercase tracking-wider text-slate-500">
                                <th class="pb-3">Agriculteur</th>
                                <th class="pb-3">Borne</th>
                                <th class="pb-3 text-right">Volume</th>
                                <?php if ($viewBalances): ?>
                                    <th class="pb-3 text-right">Montant</th>
                                <?php endif; ?>
                                <th class="pb-3 text-center">Statut</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-800/50 text-sm">
                            <?php if (empty($recentTransactions)): ?>
                                <tr>
                                    <td colspan="5" class="py-4 text-center text-slate-500">Aucune transaction enregistrée.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recentTransactions as $tx): ?>
                                    <tr class="hover:bg-slate-800/20 transition-colors">
                                        <td class="py-3">
                                            <span class="font-medium text-slate-200 block"><?= htmlspecialchars($tx['farmer_prenom'] . ' ' . $tx['farmer_nom']) ?></span>
                                            <span class="text-xs text-slate-500 font-mono"><?= htmlspecialchars($tx['carte_rfid_uid']) ?></span>
                                        </td>
                                        <td class="py-3 text-slate-300 text-xs">
                                            <?= htmlspecialchars($tx['borne_nom']) ?>
                                        </td>
                                        <td class="py-3 text-right font-medium text-slate-200">
                                            <?= number_format($tx['volume_distribue'], 1) ?> L
                                        </td>
                                        <?php if ($viewBalances): ?>
                                            <td class="py-3 text-right font-semibold text-cyan-400">
                                                <?= number_format($tx['montant_debite'], 3) ?> DT
                                            </td>
                                        <?php endif; ?>
                                        <td class="py-3 text-center">
                                            <?php if ($tx['statut'] === 'reussie'): ?>
                                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">
                                                    Réussie
                                                </span>
                                            <?php elseif ($tx['statut'] === 'interrompue_erreur'): ?>
                                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-500/10 text-red-400">
                                                    Interrompue
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-400">
                                                    Annulée
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- Alertes Techniques / Journal d'incidents -->
        <div class="glass-card rounded-2xl p-6 <?= $viewTransactions ? '' : 'lg:col-span-3' ?>">
            <h2 class="text-lg font-bold text-slate-200 mb-6 flex items-center gap-2">
                <i data-lucide="bell-ring" class="w-5 h-5 text-red-400"></i>
                Journal des Alertes
            </h2>

            <div class="space-y-4 max-h-[350px] overflow-y-auto pr-1">
                <?php if (empty($alerts)): ?>
                    <div class="text-center py-8">
                        <div class="inline-flex w-10 h-10 rounded-full bg-slate-800 text-slate-500 items-center justify-center mb-3">
                            <i data-lucide="shield-check" class="w-5 h-5"></i>
                        </div>
                        <p class="text-xs text-slate-500">Aucun incident détecté.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($alerts as $alert): ?>
                        <div class="p-3.5 rounded-xl border transition-all duration-300 <?= $alert['resolu'] ? 'bg-slate-900/30 border-slate-800/60 text-slate-400' : 'bg-red-500/5 border-red-500/20 text-slate-200' ?>">
                            <div class="flex items-center justify-between mb-1.5">
                                <span class="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 <?= $alert['resolu'] ? 'text-slate-500' : 'text-red-400' ?>">
                                    <i data-lucide="alert-circle" class="w-3.5 h-3.5"></i>
                                    <?= str_replace('_', ' ', $alert['type_alerte']) ?>
                                </span>
                                <span class="text-[10px] text-slate-500">
                                    <?= date('d/m H:i', strtotime($alert['date_heure'])) ?>
                                </span>
                            </div>
                            <p class="text-xs line-clamp-2 leading-relaxed mb-2"><?= htmlspecialchars($alert['description']) ?></p>
                            <div class="flex items-center justify-between text-[10px] border-t <?= $alert['resolu'] ? 'border-slate-800/40' : 'border-red-500/10' ?> pt-2">
                                <span class="font-semibold text-slate-500 font-mono"><?= htmlspecialchars($alert['borne_nom']) ?></span>
                                <?php if ($alert['resolu']): ?>
                                    <span class="text-emerald-500 font-medium flex items-center gap-1">
                                        <i data-lucide="check" class="w-3 h-3"></i>
                                        Résolue
                                    </span>
                                <?php else: ?>
                                    <div class="flex items-center gap-2">
                                        <span class="text-red-400 font-semibold animate-pulse">Non résolue</span>
                                        <a href="index.php?route=alertes/resolve&id=<?= (int)$alert['id'] ?>"
                                           onclick="return confirm('Marquer cette alerte comme résolue ?')"
                                           class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold border transition-all"
                                           style="background:var(--success-bg);border-color:var(--success-border);color:var(--success)">
                                            <i data-lucide="check-circle" class="w-2.5 h-2.5"></i>
                                            Résoudre
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tableau : État des Cartes RFID & Clients -->
    <?php if ($viewClients): ?>
        <div class="glass-card rounded-2xl p-6">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <h2 class="text-lg font-bold text-slate-200 flex items-center gap-2">
                    <i data-lucide="credit-card" class="w-5 h-5 text-blue-400"></i>
                    Gestion des Clients &amp; Cartes RFID
                </h2>
                <?php if ($manageClients): ?>
                    <button onclick="openClientModal()" class="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-all flex items-center gap-1.5 shadow-lg shadow-blue-600/10">
                        <i data-lucide="user-plus" class="w-4 h-4"></i>
                        Ajouter Client
                    </button>
                <?php endif; ?>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-slate-800 text-xs font-semibold uppercase tracking-wider text-slate-500">
                            <th class="pb-3">Client</th>
                            <th class="pb-3">N° Carte RFID</th>
                            <th class="pb-3">Code PIN</th>
                            <?php if ($viewBalances): ?>
                                <th class="pb-3 text-right">Solde</th>
                            <?php endif; ?>
                            <th class="pb-3 text-right">Total Distribué</th>
                            <th class="pb-3">Dernière utilisation</th>
                            <th class="pb-3 text-center">Statut</th>
                            <?php if ($canRecharge || $manageClients): ?>
                                <th class="pb-3 text-right">Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/50 text-sm">
                        <?php if (empty($cards)): ?>
                            <tr>
                                <td colspan="8" class="py-4 text-center text-slate-500">Aucun client avec carte RFID enregistré.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($cards as $c): ?>
                                <tr class="hover:bg-slate-800/20 transition-colors">
                                    <td class="py-3">
                                        <span class="font-semibold text-slate-200 block"><?= htmlspecialchars($c['farmer_prenom'] . ' ' . $c['farmer_nom']) ?></span>
                                        <span class="text-xs text-slate-400"><?= htmlspecialchars($c['farmer_telephone']) ?></span>
                                    </td>
                                    <td class="py-3 font-mono text-xs text-slate-400">
                                        <?= htmlspecialchars($c['uid']) ?>
                                    </td>
                                    <td class="py-3 font-mono text-xs text-slate-400">
                                        <?= !empty($c['code_pin']) ? (strlen($c['code_pin']) === 4 ? htmlspecialchars($c['code_pin']) : '<span class="text-slate-500 italic text-[10px]">Haché (Bcrypt)</span>') : '<span class="text-slate-600 italic">Aucun</span>' ?>
                                    </td>
                                    <?php if ($viewBalances): ?>
                                        <td class="py-3 text-right font-bold text-emerald-400">
                                            <?= number_format($c['solde'], 3) ?> DT
                                        </td>
                                    <?php endif; ?>
                                    <td class="py-3 text-right font-medium text-slate-300">
                                        <?= number_format($c['total_distribue'], 1) ?> L
                                    </td>
                                    <td class="py-3 text-slate-500 text-xs">
                                        <?= $c['derniere_utilisation'] ? date('d/m/Y H:i', strtotime($c['derniere_utilisation'])) : 'Jamais' ?>
                                    </td>
                                    <td class="py-3 text-center">
                                        <?php if ($c['statut'] === 'active'): ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">
                                                Active
                                            </span>
                                        <?php elseif ($c['statut'] === 'suspendue'): ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400">
                                                Suspendue
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-500/10 text-red-400">
                                                Perdue
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if ($canRecharge || $manageClients): ?>
                                        <td class="py-3 text-right">
                                            <div class="flex items-center justify-end gap-2">
                                                <!-- Recharge -->
                                                <?php if ($canRecharge): ?>
                                                    <button onclick="openRechargeModal('<?= $c['uid'] ?>', '<?= htmlspecialchars($c['farmer_prenom'] . ' ' . $c['farmer_nom']) ?>', '<?= $c['solde'] ?>')" class="p-1.5 hover:bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:border-emerald-500/30 rounded-lg transition-all" title="Recharger la carte">
                                                        <i data-lucide="plus-circle" class="w-4 h-4"></i>
                                                    </button>
                                                <?php endif; ?>
                                                
                                                <?php if ($manageClients): ?>
                                                    <!-- Edit Status -->
                                                    <?php if ($c['statut'] === 'active'): ?>
                                                        <a href="index.php?route=cards/status&uid=<?= $c['uid'] ?>&status=suspendue" class="p-1.5 hover:bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:border-amber-500/30 rounded-lg transition-all" title="Suspendre la carte">
                                                            <i data-lucide="slash" class="w-4 h-4"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="index.php?route=cards/status&uid=<?= $c['uid'] ?>&status=active" class="p-1.5 hover:bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:border-emerald-500/30 rounded-lg transition-all" title="Activer la carte">
                                                            <i data-lucide="check" class="w-4 h-4"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <!-- Edit client -->
                                                    <button onclick="openEditClientModal(<?= $c['agriculteur_id'] ?>, '<?= htmlspecialchars($c['farmer_nom']) ?>', '<?= htmlspecialchars($c['farmer_prenom']) ?>', '<?= htmlspecialchars($c['farmer_telephone']) ?>', '<?= htmlspecialchars($c['farmer_email']) ?>', '<?= htmlspecialchars($c['statut']) ?>', '<?= (strlen($c['code_pin']) === 4) ? htmlspecialchars($c['code_pin']) : '' ?>')" class="p-1.5 hover:bg-blue-500/10 text-blue-400 border border-blue-500/20 hover:border-blue-500/30 rounded-lg transition-all" title="Modifier le client">
                                                        <i data-lucide="edit-3" class="w-4 h-4"></i>
                                                    </button>
                                                    <!-- Delete client -->
                                                    <a href="index.php?route=farmers/delete&id=<?= $c['agriculteur_id'] ?>" onclick="return confirm('Voulez-vous vraiment supprimer cet agriculteur et sa carte RFID ?')" class="p-1.5 hover:bg-red-500/10 text-red-400 border border-red-500/20 hover:border-red-500/30 rounded-lg transition-all" title="Supprimer le client">
                                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- ==================================================== -->
<!-- ONGLET 2: PARAMÈTRES SYSTÈME                          -->
<!-- ==================================================== -->
<?php if ($isAdmin): ?>
    <div id="tab-config" class="tab-content hidden">
        <div class="max-w-xl">
            <div class="glass-card rounded-2xl p-6">
                <h2 class="text-lg font-bold text-slate-200 mb-6 flex items-center gap-2">
                    <i data-lucide="sliders" class="w-5 h-5 text-blue-400"></i>
                    Configuration Globale
                </h2>

                <form action="index.php?route=settings/save" method="POST" class="space-y-6">
                    <div>
                        <label for="price_per_litre" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Tarif de l'eau (DT / Litre)</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500 text-sm font-semibold">DT</span>
                            <input type="text" name="price_per_litre" id="price_per_litre" required
                                   value="<?= htmlspecialchars(number_format($configs['price_per_litre'] ?? 0.200, 3)) ?>"
                                   placeholder="0.200"
                                   class="block w-full pl-9 pr-4 py-3 bg-slate-900/60 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-100 text-sm rounded-xl outline-none transition-all duration-300">
                        </div>
                        <p class="text-[10px] text-slate-500 mt-1">Exemple : 0.200 DT par litre correspond à 200 DT pour 1 m³ (1000 litres).</p>
                    </div>

                    <button type="submit" class="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-sm transition-all flex items-center gap-1.5 shadow-lg shadow-blue-600/10">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        Sauvegarder les paramètres
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- ==================================================== -->
<!-- ONGLET 3: COMPTES & ACCÈS                            -->
<!-- ==================================================== -->
<?php if ($isAdmin): ?>
    <div id="tab-users" class="tab-content hidden">
        <div class="glass-card rounded-2xl p-6">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <h2 class="text-lg font-bold text-slate-200 flex items-center gap-2">
                    <i data-lucide="users" class="w-5 h-5 text-blue-400"></i>
                    Gestion du Personnel d'Administration
                </h2>
                <button onclick="openAdminModal()" class="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-all flex items-center gap-1.5 shadow-lg shadow-blue-600/10">
                    <i data-lucide="plus" class="w-4 h-4"></i>
                    Nouveau Compte
                </button>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-slate-800 text-xs font-semibold uppercase tracking-wider text-slate-500">
                            <th class="pb-3">Personnel</th>
                            <th class="pb-3">Adresse Email</th>
                            <th class="pb-3">Date de création</th>
                            <th class="pb-3 text-center">Statut</th>
                            <th class="pb-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/50 text-sm">
                        <?php if (empty($admins)): ?>
                            <tr>
                                <td colspan="5" class="py-4 text-center text-slate-500">Aucun compte administrateur créé.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($admins as $ad): ?>
                                <tr class="hover:bg-slate-800/20 transition-colors">
                                    <td class="py-3">
                                        <span class="font-semibold text-slate-200 block"><?= htmlspecialchars($ad['prenom'] . ' ' . $ad['nom']) ?></span>
                                        <span class="text-xs text-slate-500">Rôle : <?= htmlspecialchars(ucfirst($ad['role'])) ?></span>
                                        <div class="flex flex-wrap gap-1 mt-1">
                                            <?php if ($ad['role'] === 'admin'): ?>
                                                <span class="px-1.5 py-0.5 text-[9px] font-semibold bg-blue-500/10 text-blue-400 rounded-md">Toutes les permissions</span>
                                            <?php else: ?>
                                                <?php if ($ad['perm_view_clients']): ?><span class="px-1.5 py-0.5 text-[9px] font-semibold bg-slate-800 text-slate-400 rounded-md">Clients</span><?php endif; ?>
                                                <?php if ($ad['perm_view_balances']): ?><span class="px-1.5 py-0.5 text-[9px] font-semibold bg-slate-800 text-slate-400 rounded-md">Soldes</span><?php endif; ?>
                                                <?php if ($ad['perm_view_transactions']): ?><span class="px-1.5 py-0.5 text-[9px] font-semibold bg-slate-800 text-slate-400 rounded-md">Transactions</span><?php endif; ?>
                                                <?php if ($ad['perm_manage_clients']): ?><span class="px-1.5 py-0.5 text-[9px] font-semibold bg-slate-800 text-slate-400 rounded-md">Gestion</span><?php endif; ?>
                                                <?php if ($ad['perm_can_recharge']): ?><span class="px-1.5 py-0.5 text-[9px] font-semibold bg-slate-800 text-slate-400 rounded-md">Recharge</span><?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="py-3 text-slate-300">
                                        <?= htmlspecialchars($ad['email']) ?>
                                    </td>
                                    <td class="py-3 text-slate-500 text-xs">
                                        <?= date('d/m/Y H:i', strtotime($ad['created_at'])) ?>
                                    </td>
                                    <td class="py-3 text-center">
                                        <?php if ($ad['statut'] === 'actif'): ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">
                                                Actif
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-500/10 text-red-400">
                                                Suspendu
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 text-right">
                                        <div class="flex items-center justify-end gap-2">
                                            <!-- Edit admin -->
                                            <button onclick="openAdminModal(<?= $ad['id'] ?>, '<?= htmlspecialchars($ad['nom']) ?>', '<?= htmlspecialchars($ad['prenom']) ?>', '<?= htmlspecialchars($ad['email']) ?>', '<?= htmlspecialchars($ad['statut']) ?>', '<?= htmlspecialchars($ad['role']) ?>', <?= $ad['perm_view_clients'] ?>, <?= $ad['perm_view_balances'] ?>, <?= $ad['perm_view_transactions'] ?>, <?= $ad['perm_manage_clients'] ?>, <?= $ad['perm_can_recharge'] ?>)" class="p-1.5 hover:bg-blue-500/10 text-blue-400 border border-blue-500/20 hover:border-blue-500/30 rounded-lg transition-all" title="Modifier le compte">
                                                <i data-lucide="edit-3" class="w-4 h-4"></i>
                                            </button>
                                            <!-- Delete admin -->
                                            <a href="index.php?route=admins/delete&id=<?= $ad['id'] ?>" onclick="return confirm('Voulez-vous vraiment supprimer ce compte administrateur ?')" class="p-1.5 hover:bg-red-500/10 text-red-400 border border-red-500/20 hover:border-red-500/30 rounded-lg transition-all" title="Supprimer le compte">
                                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- ==================================================== -->
<!-- MODALS ET OVERLAYS                                   -->
<!-- ==================================================== -->

<!-- 1. Recharge Modal -->
<div id="recharge-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm hidden">
    <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl animate-fade-in mx-4">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-lg font-bold text-slate-100 flex items-center gap-2">
                <i data-lucide="coins" class="w-5 h-5 text-emerald-400"></i>
                Recharger le solde
            </h3>
            <button onclick="closeRechargeModal()" class="text-slate-400 hover:text-slate-200">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="index.php?route=cards/recharge" method="POST" class="space-y-5">
            <input type="hidden" name="uid" id="recharge-uid">
            
            <div>
                <p class="text-xs text-slate-400 mb-2">Agriculteur : <strong id="recharge-farmer-name" class="text-slate-200">--</strong></p>
                <p class="text-xs text-slate-400 mb-4">Solde actuel : <strong id="recharge-current-balance" class="text-emerald-400 font-mono">0.000 DT</strong></p>
                
                <label for="recharge-amount" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Montant de la recharge (DT)</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500 text-sm font-semibold">DT</span>
                    <input type="text" name="amount" id="recharge-amount" required
                           placeholder="0.000"
                           class="block w-full pl-9 pr-4 py-3 bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                </div>
            </div>

            <div class="flex gap-3 mt-6">
                <button type="button" onclick="closeRechargeModal()" class="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm transition-all text-center">
                    Annuler
                </button>
                <button type="submit" class="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-sm transition-all shadow-lg shadow-emerald-600/10">
                    Valider la recharge
                </button>
            </div>
        </form>
    </div>
</div>

<!-- 2. Ajouter Client Modal (Agriculteur + Carte RFID) -->
<div id="client-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm hidden">
    <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl animate-fade-in mx-4">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-lg font-bold text-slate-100 flex items-center gap-2">
                <i data-lucide="user-plus" class="w-5 h-5 text-blue-400"></i>
                Ajouter un nouveau client
            </h3>
            <button onclick="closeClientModal()" class="text-slate-400 hover:text-slate-200">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="index.php?route=clients/store" method="POST" class="space-y-4">
            <div>
                <label for="client-prenom" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Prénom</label>
                <input type="text" name="prenom" id="client-prenom" required placeholder="Ex: Mohamed"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="client-nom" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Nom de famille</label>
                <input type="text" name="nom" id="client-nom" required placeholder="Ex: Ben Ali"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="client-phone" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">N° Téléphone</label>
                <input type="text" name="telephone" id="client-phone" required placeholder="Ex: +21698765432"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="client-email" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Adresse Email (Optionnel)</label>
                <input type="email" name="email" id="client-email" placeholder="Ex: mohamed@email.com"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div class="border-t border-slate-800 my-4 pt-4">
                <h4 class="text-xs font-bold text-blue-400 uppercase tracking-wider mb-3">Association de la carte RFID</h4>
                <div class="grid grid-cols-3 gap-3">
                    <div>
                        <label for="client-uid" class="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">UID RFID</label>
                        <input type="text" name="uid" id="client-uid" required placeholder="04A32B..."
                               class="block w-full px-3 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-xs rounded-xl outline-none font-mono">
                    </div>
                    <div>
                        <label for="client-solde" class="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">Solde (DT)</label>
                        <input type="text" name="solde" id="client-solde" placeholder="50.000"
                               class="block w-full px-3 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-xs rounded-xl outline-none">
                    </div>
                    <div>
                        <label for="client-pin" class="block text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">Code PIN</label>
                        <input type="text" name="code_pin" id="client-pin" placeholder="1234" maxlength="4" pattern="\d{4}"
                               class="block w-full px-3 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-xs rounded-xl outline-none font-mono">
                    </div>
                </div>
            </div>

            <div class="flex gap-3 mt-6">
                <button type="button" onclick="closeClientModal()" class="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm transition-all text-center">
                    Annuler
                </button>
                <button type="submit" class="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-sm transition-all shadow-lg shadow-blue-600/10">
                    Créer le client
                </button>
            </div>
        </form>
    </div>
</div>

<!-- 3. Modifier Client Modal -->
<div id="edit-client-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm hidden">
    <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl animate-fade-in mx-4">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-lg font-bold text-slate-100 flex items-center gap-2">
                <i data-lucide="edit-3" class="w-5 h-5 text-blue-400"></i>
                Modifier les détails du client
            </h3>
            <button onclick="closeEditClientModal()" class="text-slate-400 hover:text-slate-200">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="index.php?route=farmers/update" method="POST" class="space-y-4">
            <input type="hidden" name="id" id="edit-client-id">
            <div>
                <label for="edit-client-prenom" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Prénom</label>
                <input type="text" name="prenom" id="edit-client-prenom" required
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="edit-client-nom" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Nom de famille</label>
                <input type="text" name="nom" id="edit-client-nom" required
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="edit-client-phone" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">N° Téléphone</label>
                <input type="text" name="telephone" id="edit-client-phone" required
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="edit-client-email" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Adresse Email</label>
                <input type="email" name="email" id="edit-client-email"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>
            <div>
                <label for="edit-client-status" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Statut du compte</label>
                <select name="statut" id="edit-client-status" class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                    <option value="actif">Actif</option>
                    <option value="suspendu">Suspendu</option>
                </select>
            </div>
            <div>
                <label for="edit-client-pin" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Code PIN de la Carte</label>
                <input type="text" name="code_pin" id="edit-client-pin" placeholder="Ex: 1234" maxlength="4" pattern="\d{4}"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none font-mono">
                <p class="text-[10px] text-slate-500 mt-1">Laissez vide pour conserver le PIN existant, ou saisissez 4 chiffres.</p>
            </div>

            <div class="flex gap-3 mt-6">
                <button type="button" onclick="closeEditClientModal()" class="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm transition-all text-center">
                    Annuler
                </button>
                <button type="submit" class="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-sm transition-all shadow-lg shadow-blue-600/10">
                    Mettre à jour
                </button>
            </div>
        </form>
    </div>
</div>

<!-- 4. Personnel Modal (Ajout & Edition Admin) -->
<div id="admin-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm hidden">
    <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl animate-fade-in mx-4">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-lg font-bold text-slate-100 flex items-center gap-2" id="admin-modal-title">
                <i data-lucide="user-plus" class="w-5 h-5 text-blue-400"></i>
                Nouveau compte personnel
            </h3>
            <button onclick="closeAdminModal()" class="text-slate-400 hover:text-slate-200">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="index.php?route=admins/store" method="POST" class="space-y-4">
            <input type="hidden" name="id" id="admin-id">
            
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label for="admin-prenom" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Prénom</label>
                    <input type="text" name="prenom" id="admin-prenom" required placeholder="Ex: Jean"
                           class="block w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                </div>
                <div>
                    <label for="admin-nom" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Nom</label>
                    <input type="text" name="nom" id="admin-nom" required placeholder="Ex: Dupont"
                           class="block w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                </div>
            </div>

            <div>
                <label for="admin-email" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Adresse Email</label>
                <input type="email" name="email" id="admin-email" required placeholder="Ex: jean.dupont@email.com"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
            </div>

            <div>
                <label for="admin-password" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Mot de passe</label>
                <input type="password" name="password" id="admin-password" placeholder="••••••••"
                       class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                <span class="text-[10px] text-slate-500 block mt-1" id="admin-password-help">Laissez vide pour conserver le mot de passe actuel en cas de modification.</span>
            </div>

            <div>
                <label for="admin-role" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Rôle</label>
                <select name="role" id="admin-role" onchange="applyRolePreset(this.value)" class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                    <option value="secretaire">Secrétaire</option>
                    <option value="assistant">Assistant Technique</option>
                    <option value="admin">Administrateur</option>
                    <option value="custom">Personnalisé</option>
                </select>
            </div>

            <div class="border-t border-slate-800 my-4 pt-4">
                <h4 class="text-xs font-bold text-blue-400 uppercase tracking-wider mb-3">Permissions d'accès</h4>
                <div class="space-y-3">
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-xs font-semibold block text-slate-200">Voir les clients</span>
                            <span class="text-[10px] text-slate-500">Accès à la table des clients et au total clients</span>
                        </div>
                        <input type="checkbox" name="perm_view_clients" id="admin-perm-view-clients" class="w-4.5 h-4.5 bg-slate-950 border border-slate-800 rounded focus:ring-blue-500">
                    </div>
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-xs font-semibold block text-slate-200">Voir les soldes</span>
                            <span class="text-[10px] text-slate-500">Afficher les soldes DT et KPI revenus</span>
                        </div>
                        <input type="checkbox" name="perm_view_balances" id="admin-perm-view-balances" class="w-4.5 h-4.5 bg-slate-950 border border-slate-800 rounded focus:ring-blue-500">
                    </div>
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-xs font-semibold block text-slate-200">Voir les transactions</span>
                            <span class="text-[10px] text-slate-500">Afficher le fil des consommations récentes</span>
                        </div>
                        <input type="checkbox" name="perm_view_transactions" id="admin-perm-view-transactions" class="w-4.5 h-4.5 bg-slate-950 border border-slate-800 rounded focus:ring-blue-500">
                    </div>
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-xs font-semibold block text-slate-200">Gérer les clients</span>
                            <span class="text-[10px] text-slate-500">Ajouter, modifier ou supprimer des clients</span>
                        </div>
                        <input type="checkbox" name="perm_manage_clients" id="admin-perm-manage-clients" class="w-4.5 h-4.5 bg-slate-950 border border-slate-800 rounded focus:ring-blue-500">
                    </div>
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-xs font-semibold block text-slate-200">Recharger les cartes</span>
                            <span class="text-[10px] text-slate-500">Autoriser les recharges financières</span>
                        </div>
                        <input type="checkbox" name="perm_can_recharge" id="admin-perm-can-recharge" class="w-4.5 h-4.5 bg-slate-950 border border-slate-800 rounded focus:ring-blue-500">
                    </div>
                </div>
            </div>

            <div>
                <label for="admin-status" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Statut du compte</label>
                <select name="statut" id="admin-status" class="block w-full px-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-blue-500 text-slate-100 text-sm rounded-xl outline-none">
                    <option value="actif">Actif</option>
                    <option value="suspendu">Suspendu</option>
                </select>
            </div>

            <div class="flex gap-3 mt-6">
                <button type="button" onclick="closeAdminModal()" class="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm transition-all text-center">
                    Annuler
                </button>
                <button type="submit" class="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-sm transition-all shadow-lg shadow-blue-600/10">
                    Enregistrer
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ==================================================== -->
<!-- JAVASCRIPT GESTION DES ONGLETS ET MODALS             -->
<!-- ==================================================== -->
<script>
    // Gestion du changement d'onglet
    function switchTab(tabId) {
        // Cacher tous les contenus d'onglets
        document.querySelectorAll('.tab-content').forEach(el => {
            el.classList.add('hidden');
            el.classList.remove('block');
        });

        // Désactiver le style de tous les boutons d'onglets
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.add('text-slate-400', 'border-transparent');
            btn.classList.remove('text-blue-400', 'border-blue-500');
        });

        // Afficher l'onglet actif
        const activeContent = document.getElementById('tab-' + tabId);
        if (activeContent) {
            activeContent.classList.remove('hidden');
            activeContent.classList.add('block');
        }

        // Activer le bouton de l'onglet actif
        const activeBtn = document.getElementById('tab-btn-' + tabId);
        if (activeBtn) {
            activeBtn.classList.remove('text-slate-400', 'border-transparent');
            activeBtn.classList.add('text-blue-400', 'border-blue-500');
        }
    }

    // Gestion du chargement initial pour conserver l'onglet actif sur rafraîchissement
    window.addEventListener('DOMContentLoaded', () => {
        const hash = window.location.hash.replace('#', '');
        if (hash === 'config' || hash === 'users' || hash === 'supervision') {
            switchTab(hash);
        } else {
            switchTab('supervision');
        }
    });

    // Écouter les changements d'ancre dans l'URL
    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.replace('#', '');
        if (hash === 'config' || hash === 'users' || hash === 'supervision') {
            switchTab(hash);
        }
    });

    // Modals : Recharge
    function openRechargeModal(uid, name, balance) {
        document.getElementById('recharge-uid').value = uid;
        document.getElementById('recharge-farmer-name').textContent = name;
        document.getElementById('recharge-current-balance').textContent = parseFloat(balance).toFixed(3) + ' DT';
        document.getElementById('recharge-amount').value = '';
        document.getElementById('recharge-modal').classList.remove('hidden');
    }

    function closeRechargeModal() {
        document.getElementById('recharge-modal').classList.add('hidden');
    }

    // Modals : Ajouter Client
    function openClientModal() {
        document.getElementById('client-prenom').value = '';
        document.getElementById('client-nom').value = '';
        document.getElementById('client-phone').value = '';
        document.getElementById('client-email').value = '';
        document.getElementById('client-uid').value = '';
        document.getElementById('client-solde').value = '50.000';
        document.getElementById('client-pin').value = '';
        document.getElementById('client-modal').classList.remove('hidden');
    }

    function closeClientModal() {
        document.getElementById('client-modal').classList.add('hidden');
    }

    // Modals : Modifier Client
    function openEditClientModal(id, nom, prenom, telephone, email, status, pin = '') {
        document.getElementById('edit-client-id').value = id;
        document.getElementById('edit-client-prenom').value = prenom;
        document.getElementById('edit-client-nom').value = nom;
        document.getElementById('edit-client-phone').value = telephone;
        document.getElementById('edit-client-email').value = email;
        document.getElementById('edit-client-status').value = status;
        document.getElementById('edit-client-pin').value = pin;
        document.getElementById('edit-client-modal').classList.remove('hidden');
    }

    function closeEditClientModal() {
        document.getElementById('edit-client-modal').classList.add('hidden');
    }

    // Gestion des presets de rôle pour les formulaires
    function applyRolePreset(role) {
        const presets = {
            admin:      { viewClients:true,  viewBalances:true,  viewTransactions:true,  manageClients:true,  canRecharge:true },
            secretaire: { viewClients:true,  viewBalances:true,  viewTransactions:true,  manageClients:false, canRecharge:false },
            assistant:  { viewClients:false, viewBalances:false, viewTransactions:true,  manageClients:false, canRecharge:false }
        };
        const p = presets[role];
        if (p) {
            document.getElementById('admin-perm-view-clients').checked = p.viewClients;
            document.getElementById('admin-perm-view-balances').checked = p.viewBalances;
            document.getElementById('admin-perm-view-transactions').checked = p.viewTransactions;
            document.getElementById('admin-perm-manage-clients').checked = p.manageClients;
            document.getElementById('admin-perm-can-recharge').checked = p.canRecharge;
        }
    }

    // Modals : Admin Personnel
    function openAdminModal(id = null, nom = '', prenom = '', email = '', statut = 'actif', role = 'secretaire', view_clients = 1, view_balances = 1, view_transactions = 1, manage_clients = 0, can_recharge = 0) {
        const titleEl = document.getElementById('admin-modal-title');
        const passHelp = document.getElementById('admin-password-help');
        const passInput = document.getElementById('admin-password');

        document.getElementById('admin-id').value = id;
        document.getElementById('admin-prenom').value = prenom;
        document.getElementById('admin-nom').value = nom;
        document.getElementById('admin-email').value = email;
        document.getElementById('admin-status').value = statut;
        document.getElementById('admin-role').value = role;

        document.getElementById('admin-perm-view-clients').checked = parseInt(view_clients) === 1;
        document.getElementById('admin-perm-view-balances').checked = parseInt(view_balances) === 1;
        document.getElementById('admin-perm-view-transactions').checked = parseInt(view_transactions) === 1;
        document.getElementById('admin-perm-manage-clients').checked = parseInt(manage_clients) === 1;
        document.getElementById('admin-perm-can-recharge').checked = parseInt(can_recharge) === 1;

        if (id) {
            // Modification
            titleEl.innerHTML = '<i data-lucide="edit-3" class="w-5 h-5 text-blue-400 inline"></i> Modifier compte personnel';
            passInput.required = false;
            passHelp.classList.remove('hidden');
        } else {
            // Création
            titleEl.innerHTML = '<i data-lucide="user-plus" class="w-5 h-5 text-blue-400 inline"></i> Nouveau compte personnel';
            passInput.required = true;
            passHelp.classList.add('hidden');
            applyRolePreset('secretaire');
        }
        document.getElementById('admin-modal').classList.remove('hidden');
        lucide.createIcons();
    }

    function closeAdminModal() {
        document.getElementById('admin-modal').classList.add('hidden');
    }
</script>
