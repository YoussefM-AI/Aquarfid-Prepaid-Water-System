<?php
header('Content-Type: text/plain; charset=utf-8');

try {
    $pdo = new PDO(
        'mysql:host=127.0.0.1;port=3306;dbname=water_db;charset=utf8mb4',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );

    echo "=== Diagnostic Admin ===\n\n";

    // Lire le hash actuel
    $row = $pdo->query("SELECT email, password, statut FROM administrateurs WHERE email = 'admin@water.local'")->fetch();

    if (!$row) {
        echo "ERREUR : Aucun admin trouve pour admin@water.local\n";
        exit;
    }

    echo "Email  : " . $row['email'] . "\n";
    echo "Statut : " . $row['statut'] . "\n";
    echo "Hash   : " . $row['password'] . "\n";
    echo "password_verify('admin123') = " . (password_verify('admin123', $row['password']) ? 'OUI' : 'NON') . "\n\n";

    // Generer un hash frais et corriger
    $newHash = password_hash('admin123', PASSWORD_BCRYPT);
    echo "Nouveau hash : " . $newHash . "\n\n";

    $stmt = $pdo->prepare("UPDATE administrateurs SET password = :pw WHERE email = 'admin@water.local'");
    $stmt->execute(['pw' => $newHash]);

    echo "Mise a jour : " . $stmt->rowCount() . " ligne(s) affectee(s)\n";

    // Re-verifier
    $row2 = $pdo->query("SELECT password FROM administrateurs WHERE email = 'admin@water.local'")->fetch();
    echo "Verification finale = " . (password_verify('admin123', $row2['password']) ? 'OK - Connexion devrait fonctionner' : 'ECHEC') . "\n";

} catch (Exception $e) {
    echo "ERREUR PDO : " . $e->getMessage() . "\n";
}
